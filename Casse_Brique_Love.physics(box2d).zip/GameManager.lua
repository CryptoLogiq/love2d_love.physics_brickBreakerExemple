local GameManager = {}

function GameManager.load()
end
--

function GameManager.update(dt)
end
--

function GameManager.draw()
end
--

function GameManager.keypressed(key)
end
--

function GameManager.mousepressed(x,y,button)
end
--

return GameManager
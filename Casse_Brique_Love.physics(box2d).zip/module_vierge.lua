local Module = {}

function Module.load()
end
--

function Module.update(dt)
end
--

function Module.draw()
end
--

function Module.keypressed(key)
end
--

function Module.mousepressed(x,y,button)
end
--

return Module